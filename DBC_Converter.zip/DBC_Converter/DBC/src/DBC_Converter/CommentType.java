package DBC_Converter;

public enum CommentType {
    NodeComment,
    MessageComment,
    SignalComment
}