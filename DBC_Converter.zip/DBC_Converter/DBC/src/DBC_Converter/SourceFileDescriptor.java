package DBC_Converter;

public class SourceFileDescriptor {
	private String dir;
    private String files;

    public String getDir() {
        return dir;
    }
    public void setDir(String dir) {
        this.dir = dir;
    }

    public String getFiles() {
        return files;
    }
    public void setFiles(String files) {
        this.files = files;
    }
}
