package DBC_Converter;

public enum BitLayout {
	  Intel,
	  Motorolla
}
