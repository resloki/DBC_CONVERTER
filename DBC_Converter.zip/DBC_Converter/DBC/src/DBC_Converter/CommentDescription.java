package DBC_Converter;

public class CommentDescription {
    public CommentType type;
    public int msgId;
    public String nodeName;
    public String sigName;
    public String text;
}